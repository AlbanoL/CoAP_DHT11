package it.unip.iotlab.iot2018.cf.entity;

public class Config {

	private Integer TempSup;
	private Integer TempInf;
	private Integer HumSup;
	private Integer HumInf;
	
	public Config() {
	}
	
	public void setLimiteTempSuperior(Integer valor) {
		TempSup = valor;
	}
	
	public void setLimiteTempInferior(Integer valor) {
		TempInf = valor;
	}
	
	public void setLimiteHumSuperior(Integer valor) {
		HumSup = valor;
	}
	
	public void setLimiteHumInferior(Integer valor) {
		HumInf = valor;
	}
	
	public Integer getLimiteTempSuperior() {
		return TempSup;
	}
	
	public Integer getLimiteTempInferior() {
		return TempInf;
	}
	
	public Integer getLimiteHumSuperior() {
		return HumSup;
	}
	
	public Integer getLimiteHumInferior() {
		return HumInf;
	}	
}
