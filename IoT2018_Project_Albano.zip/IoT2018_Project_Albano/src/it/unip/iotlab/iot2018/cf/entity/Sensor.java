package it.unip.iotlab.iot2018.cf.entity;

public class Sensor {

	private Integer humidity;
	private Integer temperature;
	
	public Sensor() {
	}

	public Integer getHumidity() {
		return humidity;
	}

	public void setHumidity(Integer humidity) {
		this.humidity = humidity;
	}

	public Integer getTemperature() {
		return temperature;
	}

	public void setTemperature(Integer temperature) {
		this.temperature = temperature;
	}

}
