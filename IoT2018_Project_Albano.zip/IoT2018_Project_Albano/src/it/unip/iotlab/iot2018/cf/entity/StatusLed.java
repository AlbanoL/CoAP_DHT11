package it.unip.iotlab.iot2018.cf.entity;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;

public class StatusLed {

    // gpio variables
    final GpioController gpio;
    final GpioPinDigitalOutput RLEDpin;
    final GpioPinDigitalOutput GLEDpin;
    private String redPinState;
    private String greenPinState;
    
    // constructor (initialization)
    public StatusLed(){
    	System.out.println("ENTROU no StatusLed CONSTRUTOR");
        // create gpio controller
        gpio = GpioFactory.getInstance();

        // provision gpio pins #01 and #04 as an output pins and turn them off
        RLEDpin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_01);
        GLEDpin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_04);
        
        // set shutdown state for these pins
        this.greenPinState = "n/a";
        this.redPinState = "n/a";
        RLEDpin.setState(PinState.LOW);
    	RLEDpin.low();
        GLEDpin.setState(PinState.LOW);
    	GLEDpin.low();
        
        //gpio.shutdown();
        
        gpio.unprovisionPin(RLEDpin);
        gpio.unprovisionPin(GLEDpin);   

    }

    public String getStateRedLed(){
    	//return RLEDpin.getState().getValue();
    	return this.redPinState;
    }
    
    public String getStateGreenLed(){
    	//return GLEDpin.getState().getValue();
    	return this.greenPinState;
    }
    
    public void setBlinkRedLed() {
    	this.redPinState = "temp out";
    	RLEDpin.blink(500);
    }
    
    public void setBlinkGreenLed() {
    	this.greenPinState = "humid out";
    	GLEDpin.blink(500);
    }

    public void setHighRedLed() {
    	this.redPinState = "temp in";
    	RLEDpin.blink(0);
    	RLEDpin.setState(PinState.LOW);
    	RLEDpin.high();
    }
    
    public void setHighGreenLed() {
    	this.greenPinState = "humid in";
    	GLEDpin.blink(0);
    	GLEDpin.setState(PinState.LOW);
    	GLEDpin.high();
    }
    
    // "close" object to free resources
    public void close(){
        // shutdown GPIO controller
        gpio.shutdown();   
    }
    

}
