package it.unipr.iotlab.iot2018.cf.server;

import org.eclipse.californium.core.CoapServer;

import it.unip.iotlab.iot2018.cf.entity.Sensor;
import it.unip.iotlab.iot2018.cf.entity.StatusLed;
import it.unipr.iotlab.iot2018.cf.server.resources.DHT11Resource;
import it.unipr.iotlab.iot2018.cf.server.resources.LedResource;

public class TutorialServer extends CoapServer {

	public static void main(String[] args)throws InterruptedException  
	{
		TutorialServer tutorialServer = new TutorialServer();
		
		StatusLed led = new StatusLed();
		Sensor sensor = new Sensor();
		
		DHT11Resource obsRes = new DHT11Resource("Sensores", led, sensor);
		DHT11Resource obsLimite = new DHT11Resource("CONFIG", led, sensor);
		LedResource obsLed = new LedResource("LED", led);
		
		obsRes.setObservable(true);
		obsLed.setObservable(true);
		obsLimite.setObservable(true);
		obsRes.getAttributes().setObservable();
		obsLed.getAttributes().setObservable();
		obsLimite.getAttributes().setObservable();
		tutorialServer.add(obsRes);
		tutorialServer.add(obsLed);
		tutorialServer.add(obsLimite);
		tutorialServer.start();
	}
}
