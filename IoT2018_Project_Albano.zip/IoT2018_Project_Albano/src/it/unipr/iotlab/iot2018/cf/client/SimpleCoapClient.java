package it.unipr.iotlab.iot2018.cf.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapObserveRelation;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;


public class SimpleCoapClient {
	
	private String baseUrl = "coap://192.168.3.110:5683/%s";

	public static void main(String[] args) throws IOException {
		// Create the client
		SimpleCoapClient instance = new SimpleCoapClient();
		
		// Create the reader
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		// Show usage
		System.out.println("Usage: ");
		System.out.println("- getSensors");
		System.out.println("- getLeds");
		System.out.println("- setLimits");
		System.out.println("- exit");
		
		// Read the cmd
		String cmd = "";
		while (!cmd.equals("exit")) {
			System.out.print("$ ");
			cmd = reader.readLine();
			if (cmd.equals("getSensors")) {
				CoapObserveRelation relation = instance.getSensors();
				instance.execute(relation);			
			} else if (cmd.equals("getLeds")) {
				CoapObserveRelation relation = instance.getLeds();
				instance.execute(relation);
			} else if (cmd.equals("setLimits")) {
				System.out.print("Enther the temperature [min]: ");
				int tempMin = Integer.parseInt(reader.readLine());
				System.out.print("Enther the temperature [max]: ");
				int tempMax = Integer.parseInt(reader.readLine());
				System.out.print("Enther the humidity [min]: ");
				int humidMin = Integer.parseInt(reader.readLine());
				System.out.print("Enther the humidity [max]: ");
				int humidMax = Integer.parseInt(reader.readLine());
				instance.setLimits(tempMin, tempMax, humidMin, humidMax);
			} else {
				System.out.println(String.format("Error! Unrecognized command: %s", cmd));
			}
			System.out.println("\n\n");
		}
	}
	
	public SimpleCoapClient() {
		
	}
	
	private void execute(CoapObserveRelation relation) {
		try { Thread.sleep(100); } catch (InterruptedException e) {}
		relation.reactiveCancel();
		try { Thread.sleep(100); } catch (InterruptedException e) {}
	}
	
	private CoapObserveRelation getSensors() {
		System.out.println("Reading sensors:");
		String url = String.format(this.baseUrl, "Sensores");
		CoapClient client = new CoapClient(url);
		return client.observe(new CoapHandler() {
			public void onLoad(CoapResponse response) {
				String content = response.getResponseText();
				System.out.println(content);
			}

			public void onError() {
				System.err.println("Failed to get sensors");
			}
		});
	}
	
	private CoapObserveRelation getLeds() {
		System.out.println("Reading leds:");
		String url = String.format(this.baseUrl, "LED");
		CoapClient client = new CoapClient(url);
		return client.observe(new CoapHandler() {
			public void onLoad(CoapResponse response) {
				String content = response.getResponseText();
				System.out.println(content);
			}

			public void onError() {
				System.err.println("Failed to get leds");
			}
		});
	}
	
	private void setLimits(int tempMin, int tempMax, int humidMin, int humidMax) {
		System.out.println("Setting limits:");
		String url = String.format(this.baseUrl, "CONFIG");
		CoapClient client = new CoapClient(url);
		String payload = String.format("{\"TempSup\":%s,\"TempInf\":%s,\"HumSup\":%s,\"HumInf\":%s}", tempMax, tempMin, humidMax, humidMin); 
		System.out.println(payload);
		client.put(payload, MediaTypeRegistry.TEXT_PLAIN);
	}
}
