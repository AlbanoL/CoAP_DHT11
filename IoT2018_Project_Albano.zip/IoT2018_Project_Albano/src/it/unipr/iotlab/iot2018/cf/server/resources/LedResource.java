package it.unipr.iotlab.iot2018.cf.server.resources;
import static org.eclipse.californium.core.coap.CoAP.ResponseCode.*;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;

import it.unip.iotlab.iot2018.cf.entity.StatusLed;

public class LedResource extends CoapResource {
	
	private StatusLed led;
	
	public LedResource(String name, StatusLed led) {
		super(name);
		this.led = led;
	}
	
	@Override
	public void handleGET(CoapExchange exchange) {
		// update myLEDs status with the request's content
		try {           
            String ledVermelho = this.led.getStateRedLed();
            String ledVerde = this.led.getStateGreenLed();
            
            exchange.respond(ResponseCode.CONTENT, "RED: "+ledVermelho+" GREEN: "+ ledVerde, MediaTypeRegistry.TEXT_PLAIN);
		} catch (Exception ex) {
            
			// return "bad request" if the request's content is invalid
			ex.printStackTrace();
            exchange.respond(BAD_REQUEST, "ERROR: "+ex.getMessage());
        }

	}	
}
