package it.unipr.iotlab.iot2018.cf.server.resources;

import static org.eclipse.californium.core.coap.CoAP.ResponseCode.BAD_REQUEST;
import static org.eclipse.californium.core.coap.CoAP.ResponseCode.CHANGED;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import it.unip.iotlab.iot2018.cf.entity.Config;
import it.unip.iotlab.iot2018.cf.entity.Sensor;
import it.unip.iotlab.iot2018.cf.entity.StatusLed;

public class DHT11Resource extends CoapResource {

	private Timer tempo;
	private StatusLed led;
	private Sensor sen;
	private String measure = "";

	// Constructor
	public DHT11Resource(String name, StatusLed led, Sensor sensor) {
		// Define resource name
		super(name);

		// Create a Timer object to get DHT11 readings each 3 seconds
		this.tempo = new Timer();
		this.tempo.schedule(new UpdateTask(this), 0, 3000);
		
		this.led = led;
		this.sen = sensor;
	}

	// Method to update readings
	public class UpdateTask extends TimerTask {

		// Private Variables
		private CoapResource mCoapRes;

		// Private method to read sensor data using a Python script

		private String getSensorData() {
			String sensorData = null;
			try {
				Runtime rt = Runtime.getRuntime();
				// Execute script dht.py with two arguments
				// - 1: sensor model (11)
				// - 2: GPIO pin (3)
				Process p = rt.exec("python dht2.py 11 3");
				BufferedReader bri = new BufferedReader(new InputStreamReader(p.getInputStream()));
				sensorData = bri.readLine();
				bri.close();
				p.waitFor();
			} catch (Exception e) {
				e.printStackTrace();
			}
			// This method returns NULL if no data is available (fail reading data)
			return sensorData;
		}

		public UpdateTask(CoapResource coapRes) {
			mCoapRes = coapRes;
		}

		// Custom method to update resource data (measure)
		@Override
		public void run() {
			String newMeasure = getSensorData();

			if (!newMeasure.equals(measure) && (newMeasure != null)) {
				measure = newMeasure;
				mCoapRes.changed();
			}

		}
	}

	// Custom method to handle GET requests
	@Override
	public void handleGET(CoapExchange exchange) {
		try {
			Gson g = new GsonBuilder().create();
			System.out.println(this.measure);
			this.sen = g.fromJson(measure, Sensor.class);

			exchange.respond(ResponseCode.CONTENT,
					"Temperature: " + this.sen.getTemperature() + "*C Humidity:" + this.sen.getHumidity() + "%",
					MediaTypeRegistry.TEXT_PLAIN);
		} catch (Exception ex) {
			// ex.printStackTrace();
			exchange.respond(BAD_REQUEST, "ERROR:" + ex.getMessage(), MediaTypeRegistry.TEXT_PLAIN);
		}
	}

	@Override
	public void handlePUT(CoapExchange exchange) {
		this.handlePOST(exchange);
	}

	@Override
	public void handlePOST(CoapExchange exchange) {
		try {
			Gson g = new GsonBuilder().create();
			Config conf = new Config();
			conf = g.fromJson(exchange.getRequestText(), Config.class);
			// StatusLed led = new StatusLed();
			// Sensor sen = new Sensor();
			this.sen = g.fromJson(measure, Sensor.class);
			// get the request's content to be used further

			if ((this.sen.getTemperature() > conf.getLimiteTempSuperior())
					|| (this.sen.getTemperature() < conf.getLimiteTempInferior())) {
				System.out.println("Temp start blinking");
				this.led.setBlinkRedLed();
			} else {
				System.out.println("Temp stop blinking");
				this.led.setHighRedLed();
			}

			if ((this.sen.getHumidity() > conf.getLimiteHumSuperior())
					|| (this.sen.getHumidity() < conf.getLimiteHumInferior())) {
				System.out.println("Humid start blinking");
				this.led.setBlinkGreenLed();
			} else {
				System.out.println("Humid stop blinking");
				this.led.setHighGreenLed();
			}

			exchange.respond(CHANGED, exchange.getRequestText());
		} catch (Exception ex) {

			// return "bad request" if the request's content is invalid
			ex.printStackTrace();
			exchange.respond(BAD_REQUEST, "ERROR:" + ex.getMessage(), MediaTypeRegistry.TEXT_PLAIN);
		}

	}
}