package it.unipr.iotlab.iot2018.cf.task;

import java.util.Random;
import java.util.TimerTask;

import it.unipr.iotlab.iot2018.cf.server.resources.ObservableResource;

public class UpdateTask extends TimerTask {

	private ObservableResource mCoapRes;

	public UpdateTask(ObservableResource coapRes) {
		mCoapRes = coapRes;
	}

	@Override
	public void run() {
		this.mCoapRes.setMvalue(new Random().nextInt(20));
		mCoapRes.changed();
	}
}
