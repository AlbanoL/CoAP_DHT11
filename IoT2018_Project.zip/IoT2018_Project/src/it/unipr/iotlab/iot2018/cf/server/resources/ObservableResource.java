package it.unipr.iotlab.iot2018.cf.server.resources;

import java.util.Timer;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;

import it.unipr.iotlab.iot2018.cf.task.UpdateTask;

public class ObservableResource extends CoapResource {

	private int mValue = 0;

	public ObservableResource(String name) {
		super(name);
		Timer timer = new Timer();
		timer.schedule(new UpdateTask(this), 0, 1000);
	}

	public int getMvalue() {
		return this.mValue;
	}

	public void setMvalue(int mValue) {
		this.mValue = mValue;
	}

	@Override
	public void handleGET(CoapExchange exchange) {
		exchange.respond(ResponseCode.CONTENT, this.mValue + " (Valor do mValue)", MediaTypeRegistry.TEXT_PLAIN);

	}

	public void handlePOST(CoapExchange exchange) {
		exchange.respond(ResponseCode.CONTENT, "Hello World!", MediaTypeRegistry.TEXT_PLAIN);

	}

	public void handlePUT(CoapExchange exchange) {
		exchange.respond(ResponseCode.CONTENT, "Hello World!", MediaTypeRegistry.TEXT_PLAIN);

	}

	public void handleDELETE(CoapExchange exchange) {
		exchange.respond(ResponseCode.CONTENT, "Hello World!", MediaTypeRegistry.TEXT_PLAIN);

	}
}
